require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const paymentsRouter = require('./routes/payments');
const uploadsRouter = require('./routes/uploads');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

app.use('/api/payments', paymentsRouter);
app.use('/api/uploads', uploadsRouter);

app.get('/', (req, res) => res.json({ status: 'backend running' }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend listening on ${PORT}`));
