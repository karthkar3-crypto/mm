const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const plagiarismService = require('../services/plagiarism');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '..', '..', 'uploads')),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const name = `${Date.now()}-${Math.random().toString(36).slice(2,9)}${ext}`;
    cb(null, name);
  }
});

const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

router.post('/file', upload.single('document'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'no file' });
    const filePath = req.file.path;

    // استدعاء خدمة فحص الاستلال (مبدئي)
    const report = await plagiarismService.check(filePath);

    res.json({ message: 'File uploaded', filePath, report });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Upload failed' });
  }
});

module.exports = router;
