module.exports = {
  async check(filePath) {
    // مبدئي: لا يتصل بخدمة خارجية، يعيد نموذج تقرير. لاحقًا يمكن ربط Turnitin/Plagscan.
    return {
      score: Math.round(Math.random() * 30),
      summary: 'This is a mock plagiarism result. Integrate real API for production.',
    };
  }
};
