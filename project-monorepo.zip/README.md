مشروع (Express + React + Stripe) - نسخة قابلة للرفع على منصات بدون VS Code (Replit, Railway...)

تعليمات سريعة:
- ضع مفاتيح Stripe في ملفات المتغيرات البيئية أو لوحة التحكم في المنصة.
- لتشغيل محلياً: شغّل backend ثم frontend (أو `npm run build` في frontend وخدم dist من backend).
